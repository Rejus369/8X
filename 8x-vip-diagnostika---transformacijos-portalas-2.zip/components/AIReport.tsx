
import React from 'react';
import { AIAnalysis } from '../types';

interface AIReportProps {
  analysis: AIAnalysis;
  userEmail?: string;
  onReset: () => void;
}

const AIReport: React.FC<AIReportProps> = ({ analysis, userEmail, onReset }) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-6xl mx-auto space-y-24 animate-fade px-6">
      <header className="text-center space-y-8">
        <div className="text-[#b89454] text-[10px] font-bold uppercase tracking-[0.6em]">Egzistencinis Protokolas</div>
        <h1 className="serif text-4xl md:text-6xl font-bold uppercase tracking-wider text-zinc-800">
          VIP <span className="text-[#b89454]">Reziumė</span>
        </h1>
        <div className="max-w-3xl mx-auto py-10 border-y border-zinc-100">
            <p className="text-zinc-600 text-xl font-light leading-relaxed serif italic tracking-wide">
              "{analysis.summary}"
            </p>
        </div>
      </header>

      {/* Archetype Highlight */}
      <div className="bg-[#1a1a1a] text-white p-12 md:p-20 rounded-lg card-shadow text-center space-y-6 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
          <div className="w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-gold-500/20 via-transparent to-transparent"></div>
        </div>
        <div className="text-[10px] font-bold text-[#b89454] uppercase tracking-[0.5em]">Energijos Architektūra</div>
        <h2 className="serif text-3xl md:text-5xl font-bold uppercase tracking-widest">{analysis.energyArchetype}</h2>
        <div className="h-px w-20 bg-[#b89454] mx-auto"></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <Card title="Tapatybės Dekonstrukcija" content={analysis.identityAnalysis} label="ESMĖ" />
        <Card title="Mirtingumo Lęšis" content={analysis.mortalityLens} label="LAIKAS" highlight />
        <Card title="Finansinis Blueprintas" content={analysis.financialBlueprint} label="TURTAS" />
        <Card title="Nervų Sistemos Talpa" content={analysis.nervousSystemInsight} label="KŪNAS" />
        <Card title="Rutinos & Energijos Auditas" content={analysis.routineAndEnergyHygiene} label="HIGIENA" />
        <Card title="Potencialas" content={analysis.purposeAndPotential} label="VIZIJA" />
      </div>

      <div className="bg-white card-shadow p-12 md:p-24 rounded-lg relative overflow-hidden max-w-4xl mx-auto border-t-4 border-[#b89454]">
        <div className="relative z-10 space-y-12">
            <h3 className="serif text-3xl font-bold text-zinc-800 uppercase tracking-widest text-center">Strateginis Proveržis</h3>
            <div className="text-zinc-800 leading-relaxed font-medium space-y-4 whitespace-pre-line text-lg max-w-2xl mx-auto">
              {analysis.recommendation}
            </div>
        </div>
      </div>

      <div className="flex flex-col items-center gap-12 pt-10 pb-20 no-print">
        <div className="text-center space-y-2">
          <p className="text-zinc-400 uppercase tracking-[0.3em] text-[10px] font-black">Konfidenciali medžiaga</p>
          <p className="text-[#b89454] serif text-lg italic">{userEmail}</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4 w-full justify-center px-4">
            <button
              onClick={handlePrint}
              className="px-10 py-5 rounded-full text-[10px] tracking-[0.3em] font-bold border-2 border-zinc-200 text-zinc-400 hover:border-[#b89454] hover:text-[#b89454] transition-all uppercase"
            >
              ATSISIŲSTI PDF
            </button>
            <button
              onClick={onReset}
              className="btn-brand px-16 py-6 rounded-full text-xs"
            >
              NAUJA ANALIZĖ
            </button>
        </div>
      </div>
    </div>
  );
};

const Card: React.FC<{ title: string; content: string; label: string; highlight?: boolean }> = ({ title, content, label, highlight }) => (
  <div className={`p-10 rounded-lg card-shadow transition-all duration-500 group border-b-2 ${highlight ? 'bg-zinc-50 border-[#b89454]' : 'bg-white border-transparent hover:border-[#b89454]'}`}>
    <div className="text-[10px] font-black text-[#b89454]/60 tracking-[0.4em] mb-6 uppercase">{label}</div>
    <h3 className="serif text-xl font-bold mb-6 text-zinc-800 transition-colors uppercase tracking-wider">{title}</h3>
    <p className="text-zinc-500 text-sm leading-relaxed font-light">{content}</p>
  </div>
);

export default AIReport;
