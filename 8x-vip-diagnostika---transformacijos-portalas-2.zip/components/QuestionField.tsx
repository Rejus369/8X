
import React from 'react';
import { Question } from '../types';

interface QuestionFieldProps {
  question: Question;
  value: string | number;
  onChange: (id: string, value: string | number) => void;
}

const QuestionField: React.FC<QuestionFieldProps> = ({ question, value, onChange }) => {
  const baseClasses = "w-full bg-[#fcfbf9] border border-[#e5e1d8] rounded-sm px-5 py-4 focus:outline-none focus:border-[#b89454] transition-all text-[#2c2c2c] placeholder-zinc-300 font-light text-base";

  const renderHeader = () => (
    <div className="space-y-1">
      <label className="block text-[11px] font-bold text-zinc-500 uppercase tracking-[0.2em]">{question.label}</label>
      {question.description && (
        <p className="text-[10px] text-zinc-400 font-medium italic leading-relaxed">{question.description}</p>
      )}
    </div>
  );

  switch (question.type) {
    case 'long-text':
      return (
        <div className="space-y-4">
          {renderHeader()}
          <textarea
            className={`${baseClasses} min-h-[120px] resize-none`}
            placeholder={question.placeholder || "Jūsų mintys..."}
            value={value || ''}
            onChange={(e) => onChange(question.id, e.target.value)}
          />
        </div>
      );

    case 'number':
      return (
        <div className="space-y-4">
          {renderHeader()}
          <input
            type="number"
            className={baseClasses}
            min={question.min}
            max={question.max}
            placeholder={question.placeholder}
            value={value || ''}
            onChange={(e) => onChange(question.id, parseInt(e.target.value))}
          />
        </div>
      );

    case 'choice':
      return (
        <div className="space-y-4">
          {renderHeader()}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {question.options?.map((option) => (
              <button
                key={option}
                onClick={() => onChange(question.id, option)}
                className={`px-6 py-4 rounded-sm border text-sm text-left transition-all ${
                  value === option
                    ? "bg-[#b89454] border-[#b89454] text-white font-medium"
                    : "bg-white border-[#e5e1d8] text-zinc-500 hover:border-[#b89454]"
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        </div>
      );

    case 'scale':
      const min = question.min ?? 1;
      const max = question.max ?? 5;
      const steps = Array.from({ length: max - min + 1 }, (_, i) => min + i);
      
      return (
        <div className="space-y-5">
          {renderHeader()}
          <div className={`grid grid-cols-5 ${max > 6 ? 'sm:grid-cols-11' : 'sm:grid-cols-5'} gap-2`}>
            {steps.map((num) => (
              <button
                key={num}
                onClick={() => onChange(question.id, num)}
                className={`h-12 flex items-center justify-center rounded-sm border transition-all text-xs ${
                  value === num
                    ? "bg-[#b89454] border-[#b89454] text-white font-bold"
                    : "bg-white border-[#e5e1d8] text-zinc-400 hover:border-[#b89454]"
                }`}
              >
                {num}
              </button>
            ))}
          </div>
          <div className="flex justify-between text-[9px] text-zinc-300 font-bold uppercase tracking-widest px-1">
            <span>Minimumas</span>
            <span>Maksimumas</span>
          </div>
        </div>
      );

    default:
      return (
        <div className="space-y-4">
          {renderHeader()}
          <input
            type="text"
            className={baseClasses}
            placeholder={question.placeholder || "Įrašykite čia..."}
            value={value || ''}
            onChange={(e) => onChange(question.id, e.target.value)}
          />
        </div>
      );
  }
};

export default QuestionField;
