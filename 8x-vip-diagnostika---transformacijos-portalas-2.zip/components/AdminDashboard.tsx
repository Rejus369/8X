
import React, { useState, useEffect } from 'react';
import { Submission, AppSettings } from '../types';
import { getSubmissions, deleteSubmission, getAppSettings, saveAppSettings, updateSubmissionSyncStatus, saveSubmission } from '../services/storage';
import { syncToGoogleDrive, fetchAllSubmissions } from '../services/googleDrive';
import { FORM_SECTIONS } from '../constants';

interface AdminDashboardProps {
  onClose: () => void;
}

const GOOGLE_SCRIPT_CODE = `function doPost(e) {
  try {
    var contents = e.postData.contents;
    var data = JSON.parse(contents);
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheets()[0];
    
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(["ID", "Data", "Vardas", "El. paštas", "AI Analizė (JSON)", "Visi Atsakymai (JSON)"]);
    }
    
    sheet.appendRow([
      data.id,
      new Date(),
      data.formData.q0_name || "Nėra",
      data.formData.q0_email || "Nėra",
      JSON.stringify(data.analysis),
      JSON.stringify(data.formData)
    ]);

    if (data.formData.q0_email) {
      var email = data.formData.q0_email;
      var name = data.formData.q0_name || "Kliente";
      var analysis = data.analysis;
      
      var subject = "Jūsų VIP Diagnostikos Rezultatai | ILUMINACIÓN";
      var body = "Sveiki, " + name + ",\n\n" +
                 "Dėkojame už Jūsų laiką pildant VIP diagnostiką. Štai Jūsų asmeninė analizė:\n\n" +
                 "APIBENDRINIMAS:\n" + analysis.summary + "\n\n" +
                 "TAPATYBĖ IR SUPERGĖBĖJIMAI:\n" + analysis.identityAnalysis + "\n\n" +
                 "FINANSINIS BLUEPRINTAS:\n" + analysis.financialBlueprint + "\n\n" +
                 "NERVŲ SISTEMOS ĮŽVALGOS:\n" + analysis.nervousSystemInsight + "\n\n" +
                 "POTENCIALAS IR PRASMĖ:\n" + analysis.purposeAndPotential + "\n\n" +
                 "REKOMENDACIJOS:\n" + analysis.recommendation + "\n\n" +
                 "Linkime sėkmingos transformacijos,\nILUMINACIÓN komanda";
      
      MailApp.sendEmail(email, subject, body);
    }
    
    return ContentService.createTextOutput(JSON.stringify({status: "success"}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({status: "error", message: err.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheets()[0];
    var data = sheet.getDataRange().getValues();
    var results = [];
    
    if (data.length > 1) {
      for (var i = 1; i < data.length; i++) {
        var row = data[i];
        try {
          if (row[0] && row[5]) {
            results.push({
              id: row[0].toString(),
              timestamp: row[1],
              formData: JSON.parse(row[5]),
              analysis: row[4] ? JSON.parse(row[4]) : {},
              syncStatus: 'success'
            });
          }
        } catch (err) {}
      }
    }
    
    return ContentService.createTextOutput(JSON.stringify(results))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({error: err.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}`;

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onClose }) => {
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [selected, setSelected] = useState<Submission | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [settings, setSettings] = useState<AppSettings>(getAppSettings());
  const [isSyncing, setIsSyncing] = useState<string | null>(null);
  const [isFetching, setIsFetching] = useState(false);

  useEffect(() => {
    setSubmissions(getSubmissions());
  }, []);

  const getQuestionLabel = (id: string) => {
    for (const section of FORM_SECTIONS) {
      const q = section.questions.find(q => q.id === id);
      if (q) return q.label;
    }
    return id;
  };

  const handleCloudFetch = async () => {
    if (!settings.googleWebhookUrl || !settings.googleWebhookUrl.includes('script.google.com')) {
      alert("Nustatymuose įveskite galiojantį Google Script URL.");
      return;
    }
    
    setIsFetching(true);
    try {
      const cloudData = await fetchAllSubmissions();
      
      if (cloudData && (cloudData as any).error) {
        throw new Error((cloudData as any).error);
      }

      if (Array.isArray(cloudData)) {
        const localData = getSubmissions();
        let addedCount = 0;
        
        cloudData.forEach(item => {
          if (item && item.id && !localData.find(l => l.id === item.id)) {
            saveSubmission(item);
            addedCount++;
          }
        });
        
        setSubmissions(getSubmissions());
        alert(`Sinchronizacija baigta.\nIš viso rasta: ${cloudData.length}\nNaujų įrašų: ${addedCount}`);
      } else {
        alert("Serveris grąžino netikėtą atsakymą.");
      }
    } catch (e: any) {
      console.error(e);
      alert("Klaida siunčiantis duomenis: " + e.message);
    } finally {
      setIsFetching(false);
    }
  };

  const handleSync = async (submission: Submission) => {
    setIsSyncing(submission.id);
    const success = await syncToGoogleDrive(submission);
    if (success) {
      updateSubmissionSyncStatus(submission.id, 'success');
      setSubmissions(getSubmissions());
    } else {
      updateSubmissionSyncStatus(submission.id, 'error');
      setSubmissions(getSubmissions());
      alert("Sinchronizacija nepavyko. Patikrinkite nustatymus.");
    }
    setIsSyncing(null);
  };

  const handleDelete = (id: string) => {
    if (window.confirm("Ar tikrai norite ištrinti šį įrašą?")) {
      deleteSubmission(id);
      setSubmissions(getSubmissions());
      if (selected?.id === id) setSelected(null);
    }
  };

  const handleSaveSettings = () => {
    saveAppSettings(settings);
    setShowSettings(false);
    alert("Nustatymai išsaugoti.");
  };

  return (
    <div className="min-h-screen bg-zinc-50 flex flex-col">
      <header className="bg-white border-b border-zinc-200 px-8 py-6 flex justify-between items-center sticky top-0 z-50">
        <div className="flex items-center gap-6">
          <h2 className="serif text-xl font-bold uppercase tracking-widest text-[#b89454]">Admin Panel</h2>
          <div className="flex gap-2">
            <button 
              onClick={() => setShowSettings(!showSettings)}
              className={`text-[10px] font-bold uppercase tracking-widest px-4 py-2 rounded-full border transition-all ${showSettings ? 'bg-zinc-800 text-white border-zinc-800' : 'text-zinc-400 border-zinc-200 hover:border-zinc-800 hover:text-zinc-800'}`}
            >
              Nustatymai
            </button>
            <button 
              onClick={handleCloudFetch}
              disabled={isFetching}
              className="text-[10px] font-bold uppercase tracking-widest px-4 py-2 rounded-full border border-[#b89454] text-[#b89454] hover:bg-[#b89454] hover:text-white transition-all disabled:opacity-50"
            >
              {isFetching ? "Kraunama..." : "Importuoti iš Google"}
            </button>
          </div>
        </div>
        <button onClick={onClose} className="text-zinc-400 hover:text-black uppercase text-[10px] font-bold tracking-widest">Uždaryti</button>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar: Submissions List */}
        <aside className="w-96 bg-white border-r border-zinc-200 overflow-y-auto">
          {submissions.length === 0 ? (
            <div className="p-12 text-center text-zinc-300 uppercase text-[10px] tracking-widest font-bold">Nėra įrašų</div>
          ) : (
            submissions.map(s => (
              <div 
                key={s.id}
                onClick={() => setSelected(s)}
                className={`p-6 border-b border-zinc-50 cursor-pointer transition-all hover:bg-zinc-50 ${selected?.id === s.id ? 'bg-[#f9f7f2] border-l-4 border-l-[#b89454]' : ''}`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="text-[10px] font-bold text-[#b89454] uppercase tracking-widest">
                    {new Date(s.timestamp).toLocaleDateString()}
                  </span>
                  <div className={`w-2 h-2 rounded-full ${s.syncStatus === 'success' ? 'bg-green-400' : s.syncStatus === 'error' ? 'bg-red-400' : 'bg-zinc-200'}`} title={s.syncStatus} />
                </div>
                <div className="font-bold text-zinc-800 uppercase text-xs tracking-wider truncate mb-1">
                  {s.formData.q0_email || "Nėra el. pašto"}
                </div>
                <div className="text-zinc-400 text-[10px] truncate uppercase tracking-widest">
                   {s.formData.q0_name ? `Vardas: ${s.formData.q0_name}` : "Be vardo"}
                </div>
              </div>
            ))
          )}
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto bg-zinc-50/50 p-12">
          {showSettings ? (
            <div className="max-w-2xl bg-white p-12 rounded-lg card-shadow space-y-10 animate-fade">
              <div className="space-y-2">
                <h3 className="serif text-2xl font-bold uppercase text-zinc-800">Sistemos Nustatymai</h3>
                <p className="text-[10px] text-zinc-400 uppercase tracking-widest">Google Drive integracija</p>
              </div>

              <div className="space-y-6">
                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Google Script Webhook URL</label>
                  <input 
                    type="text" 
                    value={settings.googleWebhookUrl}
                    onChange={(e) => setSettings({ ...settings, googleWebhookUrl: e.target.value })}
                    className="w-full bg-zinc-50 border border-zinc-100 px-4 py-3 text-sm rounded focus:outline-none focus:border-[#b89454]"
                    placeholder="https://script.google.com/macros/s/.../exec"
                  />
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Google Apps Script kodas (kopijuoti į Google Script)</label>
                  <textarea 
                    readOnly
                    value={GOOGLE_SCRIPT_CODE}
                    className="w-full h-48 bg-zinc-800 text-zinc-300 p-4 font-mono text-[10px] rounded leading-relaxed resize-none"
                  />
                </div>
              </div>

              <div className="pt-6">
                <button onClick={handleSaveSettings} className="btn-brand px-10 py-4 rounded-full text-[10px]">Išsaugoti nustatymus</button>
              </div>
            </div>
          ) : selected ? (
            <div className="max-w-4xl space-y-12 animate-fade">
              <div className="flex justify-between items-start">
                <div className="space-y-2">
                  <h3 className="serif text-3xl font-bold uppercase text-zinc-800">{selected.formData.q0_email || "Nėra el. pašto"}</h3>
                  <p className="text-sm text-[#b89454] serif italic">{selected.formData.q0_name ? `Vardas: ${selected.formData.q0_name}` : ""}</p>
                </div>
                <div className="flex gap-4">
                  <button 
                    onClick={() => handleSync(selected)}
                    disabled={isSyncing === selected.id}
                    className="text-[10px] font-bold uppercase tracking-[0.2em] border border-zinc-200 px-6 py-3 rounded-full hover:border-[#b89454] hover:text-[#b89454] transition-all disabled:opacity-50"
                  >
                    {isSyncing === selected.id ? "Kraunama..." : "Persiųsti į Cloud"}
                  </button>
                  <button 
                    onClick={() => handleDelete(selected.id)}
                    className="text-[10px] font-bold uppercase tracking-[0.2em] border border-zinc-200 px-6 py-3 rounded-full hover:border-red-500 hover:text-red-500 transition-all"
                  >
                    Ištrinti
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-8">
                  <h4 className="text-[10px] font-black uppercase tracking-widest text-zinc-300 border-b border-zinc-100 pb-2">Diagnostikos Atsakymai</h4>
                  {Object.entries(selected.formData).map(([key, value]) => (
                    <div key={key} className="space-y-2">
                      <div className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest">{getQuestionLabel(key)}</div>
                      <div className="text-sm text-zinc-800 leading-relaxed bg-white p-4 rounded border border-zinc-50">{value}</div>
                    </div>
                  ))}
                </div>

                <div className="space-y-8">
                  <h4 className="text-[10px] font-black uppercase tracking-widest text-zinc-300 border-b border-zinc-100 pb-2">AI Analizė</h4>
                  <div className="space-y-6">
                    {Object.entries(selected.analysis).map(([key, value]) => (
                      <div key={key} className="space-y-2">
                        <div className="text-[9px] font-bold text-[#b89454] uppercase tracking-widest">{key.replace(/([A-Z])/g, ' $1')}</div>
                        <div className="text-sm text-zinc-600 leading-relaxed bg-[#f9f7f2] p-5 rounded italic font-light whitespace-pre-line">{value}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-6">
              <div className="w-12 h-px bg-zinc-200"></div>
              <p className="text-[10px] text-zinc-300 uppercase tracking-[0.5em] font-bold">Pasirinkite įrašą peržiūrai</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default AdminDashboard;
