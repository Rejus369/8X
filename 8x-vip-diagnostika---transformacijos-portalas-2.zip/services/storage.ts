
import { Submission, AppSettings, FormData } from "../types";

const STORAGE_KEY = '8x_vip_submissions_v1';
const SETTINGS_KEY = '8x_vip_settings_v1';
const DRAFT_KEY = '8x_vip_draft_v1';

const DEFAULT_WEBHOOK_URL = "https://script.google.com/macros/s/AKfycbwcIjeFezEqkBP305t3IXraTA9fh-_Vju7L-Dq7DVMBNUVYVQPR7A-hthzu3sj0DkjBAg/exec";

export const saveSubmission = (submission: Submission): void => {
  try {
    const existing = getSubmissions();
    const updated = [submission, ...existing];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (error) {
    console.error("Storage error:", error);
  }
};

export const updateSubmissionSyncStatus = (id: string, status: Submission['syncStatus']): void => {
  const existing = getSubmissions();
  const updated = existing.map(s => s.id === id ? { ...s, syncStatus: status } : s);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
};

export const getSubmissions = (): Submission[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error("Retrieve error:", error);
    return [];
  }
};

export const deleteSubmission = (id: string): void => {
  const existing = getSubmissions();
  const filtered = existing.filter(s => s.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
};

export const getAppSettings = (): AppSettings => {
  const data = localStorage.getItem(SETTINGS_KEY);
  if (data) {
    return JSON.parse(data);
  }
  return { googleWebhookUrl: DEFAULT_WEBHOOK_URL };
};

export const saveAppSettings = (settings: AppSettings): void => {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
};

// Draft functionality
export const saveDraft = (formData: FormData, step: number): void => {
  localStorage.setItem(DRAFT_KEY, JSON.stringify({ formData, step }));
};

export const getDraft = (): { formData: FormData; step: number } | null => {
  const data = localStorage.getItem(DRAFT_KEY);
  return data ? JSON.parse(data) : null;
};

export const clearDraft = (): void => {
  localStorage.removeItem(DRAFT_KEY);
};
