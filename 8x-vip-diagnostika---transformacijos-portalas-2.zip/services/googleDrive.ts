
import { Submission } from "../types";
import { getAppSettings } from "./storage";

export const syncToGoogleDrive = async (submission: Submission): Promise<boolean> => {
  const { googleWebhookUrl } = getAppSettings();
  
  if (!googleWebhookUrl || !googleWebhookUrl.startsWith('https://script.google.com')) {
    console.warn("Neteisingas Google Webhook URL");
    return false;
  }

  try {
    /**
     * POST užklausai naudojame mode: 'no-cors'.
     * Tai leidžia išsiųsti duomenis, net jei pilnas CORS peradresavimas naršyklėje blokuojamas.
     */
    await fetch(googleWebhookUrl, {
      method: 'POST',
      mode: 'no-cors',
      headers: {
        'Content-Type': 'text/plain',
      },
      body: JSON.stringify(submission),
    });
    return true;
  } catch (error) {
    console.error("Sync to Google Drive failed:", error);
    return false;
  }
};

export const fetchAllSubmissions = async (): Promise<Submission[]> => {
  const { googleWebhookUrl } = getAppSettings();
  if (!googleWebhookUrl || !googleWebhookUrl.startsWith('https://script.google.com')) return [];

  try {
    /**
     * Svarbu: 'Load failed' GET užklausos metu dažniausiai atsiranda dėl to, 
     * kad Google Script nepaskelbtas kaip 'Anyone' arba naršyklė blokuoja 302 peradresavimą.
     */
    const url = new URL(googleWebhookUrl);
    url.searchParams.set('_cache_buster', Date.now().toString());

    const response = await fetch(url.toString(), {
      method: 'GET',
      headers: {
        // Nenaudojame jokių papildomų headers, kad išlaikytume 'simple request' statusą
      },
      // Svarbu Google Script peradresavimams
      redirect: 'follow', 
      cache: 'no-store'
    });
    
    if (!response.ok) {
      throw new Error(`HTTP Error: ${response.status}`);
    }
    
    const text = await response.text();
    try {
      const data = JSON.parse(text);
      return Array.isArray(data) ? data : [];
    } catch (e) {
      console.error("Serveris grąžino ne JSON:", text.substring(0, 200));
      throw new Error("Gautas neteisingas atsakymo formatas. Patikrinkite Google Script klaidų žurnalą.");
    }
  } catch (error: any) {
    console.error("Failed to fetch from Google Drive:", error);
    throw error;
  }
};
