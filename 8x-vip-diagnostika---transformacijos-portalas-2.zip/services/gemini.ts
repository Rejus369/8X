
import { GoogleGenAI, Type } from "@google/genai";
import { FormData, AIAnalysis } from "../types";

export const generateDiagnosticReport = async (formData: FormData): Promise<AIAnalysis> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    Analizuok šiuos VIP kliento diagnostikos atsakymus. Tavo tonas: "Razor-sharp, philosophical, elite advisor". 
    Nenaudok klišinių koučingo frazių. Kalbėk tiesiai apie tapatybės transformaciją, mirtingumo lęšį ir energijos architektūrą.

    Ypatingą dėmesį skirk skyriui "RUTINA, PROTAS, PRAKTIKOS, ENERGETINĖ HIGIENA" – dekonstruok jų kasdienybę ir energetinę higieną.

    Kliento atsakymai:
    ${JSON.stringify(formData, null, 2)}

    Užduotis:
    1. Nustatyk kliento "Energijos Archetipą" (pvz. 'The Architect of Void', 'The Solar Dynamo', 'The Boundless Visionary').
    2. Analizuok "Mirtingumo lęšį" (Mortality Lens): Priešpriešink jų atsakymą apie 1 likusius metus (q16) su jų dabartiniais prioritetais. Identifikuok "Sąskambio spragas" (Alignment Gaps).
    3. Išanalizuok jų kasdienę rutiną (q_day_routine) ir energetinę higieną. Identifikuok energetinius nuotėkius.
    4. Pateik finansinio blueprinto analizę per nervų sistemos pajėgumą.

    Pateik atsakymą JSON formatu:
    - summary: Trumpas, autoritetingas manifestas apie kliento dabartį.
    - identityAnalysis: Gili tapatybės dekonstrukcija.
    - energyArchetype: Identifikuotas archetipas ir jo reikšmė.
    - mortalityLens: Analizė per laikinumo prizmę ir palikimo (Legacy) svorį.
    - financialBlueprint: Pinigų ir nervų sistemos ryšys.
    - nervousSystemInsight: Kaip jų kūnas "laiko" didelius skaičius ir nežinomybę.
    - routineAndEnergyHygiene: Energetinės higienos ir rutinos auditas.
    - purposeAndPotential: Kur slypi jų didžiausias netikėtas šuolis.
    - recommendation: 3 strateginiai žingsniai (aukšto lygio įžvalgos).
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING },
          identityAnalysis: { type: Type.STRING },
          energyArchetype: { type: Type.STRING },
          mortalityLens: { type: Type.STRING },
          financialBlueprint: { type: Type.STRING },
          nervousSystemInsight: { type: Type.STRING },
          routineAndEnergyHygiene: { type: Type.STRING },
          purposeAndPotential: { type: Type.STRING },
          recommendation: { type: Type.STRING },
        },
        required: ["summary", "identityAnalysis", "energyArchetype", "mortalityLens", "financialBlueprint", "nervousSystemInsight", "routineAndEnergyHygiene", "purposeAndPotential", "recommendation"]
      }
    }
  });

  try {
    const result = JSON.parse(response.text || "{}");
    return result as AIAnalysis;
  } catch (error) {
    console.error("Failed to parse AI response", error);
    throw new Error("Nepavyko sugeneruoti giliosios ataskaitos.");
  }
};
